// Firebase Authentication Configuration
// Note: This is a demo configuration. Replace with your actual Firebase credentials.

// Firebase Initialization (Demo)
// In production, import Firebase SDK and initialize with your config

const firebaseConfig = {
    apiKey: "AIzaSyDemoKey123456789",
    authDomain: "aipreneurs-global.firebaseapp.com",
    projectId: "aipreneurs-global",
    storageBucket: "aipreneurs-global.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abcdef123456"
};

// Demo Authentication Functions
// In production, integrate with actual Firebase SDK

class FirebaseAuthDemo {
    constructor() {
        this.users = {};
        this.currentUser = null;
    }

    // Sign up new user
    async signUp(email, password, role = 'student') {
        try {
            if (!this.validateEmail(email)) {
                throw new Error('Invalid email format');
            }
            if (password.length < 6) {
                throw new Error('Password must be at least 6 characters');
            }

            // Store user (in demo mode)
            this.users[email] = {
                email: email,
                password: password,
                role: role,
                createdAt: new Date()
            };

            // Set current user
            this.currentUser = { email: email, role: role };
            localStorage.setItem('userRole', role);
            localStorage.setItem('userEmail', email);

            return { success: true, user: this.currentUser };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Sign in user
    async signIn(email, password) {
        try {
            if (!this.validateEmail(email)) {
                throw new Error('Invalid email format');
            }

            // In demo mode, accept any email/password
            this.currentUser = {
                email: email,
                role: this.getUserRole(email)
            };

            localStorage.setItem('userRole', this.currentUser.role);
            localStorage.setItem('userEmail', email);

            return { success: true, user: this.currentUser };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Sign out user
    async signOut() {
        this.currentUser = null;
        localStorage.removeItem('userRole');
        localStorage.removeItem('userEmail');
        return { success: true };
    }

    // Reset password
    async resetPassword(email) {
        try {
            if (!this.validateEmail(email)) {
                throw new Error('Invalid email format');
            }
            // In demo mode, just return success
            return { success: true, message: 'Password reset email sent' };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Get current user
    getCurrentUser() {
        return this.currentUser;
    }

    // Check if user is authenticated
    isAuthenticated() {
        return this.currentUser !== null;
    }

    // Validate email format
    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Determine user role based on email pattern
    getUserRole(email) {
        if (email.includes('admin')) return 'admin';
        if (email.includes('volunteer')) return 'volunteer';
        return 'student';
    }

    // Create user profile
    async createUserProfile(userId, profileData) {
        try {
            // Store profile data
            const profile = {
                userId: userId,
                ...profileData,
                createdAt: new Date()
            };
            localStorage.setItem(`profile_${userId}`, JSON.stringify(profile));
            return { success: true, profile: profile };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Update user profile
    async updateUserProfile(userId, updates) {
        try {
            const profileStr = localStorage.getItem(`profile_${userId}`);
            const profile = profileStr ? JSON.parse(profileStr) : {};
            
            const updated = {
                ...profile,
                ...updates,
                updatedAt: new Date()
            };
            
            localStorage.setItem(`profile_${userId}`, JSON.stringify(updated));
            return { success: true, profile: updated };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Get user profile
    async getUserProfile(userId) {
        try {
            const profileStr = localStorage.getItem(`profile_${userId}`);
            const profile = profileStr ? JSON.parse(profileStr) : null;
            return { success: true, profile: profile };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

// Initialize Firebase Auth Demo
const firebaseAuth = new FirebaseAuthDemo();

// Auth State Listener
function onAuthStateChanged(callback) {
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    
    if (userRole && userEmail) {
        callback({ email: userEmail, role: userRole });
    } else {
        callback(null);
    }
}

// Export Firebase functions
window.FirebaseAuth = {
    signUp: (email, password, role) => firebaseAuth.signUp(email, password, role),
    signIn: (email, password) => firebaseAuth.signIn(email, password),
    signOut: () => firebaseAuth.signOut(),
    resetPassword: (email) => firebaseAuth.resetPassword(email),
    getCurrentUser: () => firebaseAuth.getCurrentUser(),
    isAuthenticated: () => firebaseAuth.isAuthenticated(),
    createUserProfile: (userId, data) => firebaseAuth.createUserProfile(userId, data),
    updateUserProfile: (userId, updates) => firebaseAuth.updateUserProfile(userId, updates),
    getUserProfile: (userId) => firebaseAuth.getUserProfile(userId),
    onAuthStateChanged: onAuthStateChanged
};

console.log('Firebase Auth Module Loaded (Demo Mode)');
