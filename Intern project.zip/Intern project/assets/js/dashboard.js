// AIpreneurs Dashboard - Shared Functionality

// Check user authorization
function checkUserAuth() {
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    
    if (!userRole || !userEmail) {
        window.location.href = '../pages/student-login.html';
        return null;
    }
    
    return { role: userRole, email: userEmail };
}

// Display user info
function displayUserInfo() {
    const user = checkUserAuth();
    if (user) {
        const roleText = user.role.charAt(0).toUpperCase() + user.role.slice(1);
        console.log(`${roleText} logged in: ${user.email}`);
    }
}

// Logout from dashboard
function dashboardLogout() {
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    window.location.href = '../pages/student-login.html';
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    displayUserInfo();
    
    // Add event listeners to buttons if they exist
    const settingsBtn = document.querySelector('[onclick*="Settings"]');
    const profileBtn = document.querySelector('[onclick*="Profile"]');
    
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function() {
            // Handle settings
            console.log('Settings clicked');
        });
    }
    
    if (profileBtn) {
        profileBtn.addEventListener('click', function() {
            // Handle profile
            console.log('Profile clicked');
        });
    }
});

// Export dashboard functions
window.Dashboard = {
    checkUserAuth: checkUserAuth,
    displayUserInfo: displayUserInfo,
    logout: dashboardLogout
};

console.log('Dashboard Script Loaded');
