// AIpreneurs Global Challenge 2025 - Main JavaScript

// Navbar functionality
document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('.nav-link');

    // Scroll effect on navbar
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Active link tracking
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.href === '#' || this.href.includes('#')) {
                e.preventDefault();
            }
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#' && document.querySelector(href)) {
                e.preventDefault();
                document.querySelector(href).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Intersection Observer for fade-in animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'slideUp 0.6s ease-out forwards';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all cards and sections
document.querySelectorAll('.card, .grid > div, section').forEach(el => {
    observer.observe(el);
});

// Mobile menu toggle (if needed)
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.classList.toggle('active');
    }
}

// Utility function for form validation
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Utility function for formatting dates
function formatDate(date) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(date).toLocaleDateString('en-US', options);
}

// Redirect based on user role
function redirectByRole() {
    const userRole = localStorage.getItem('userRole');
    if (userRole === 'admin') {
        window.location.href = './dashboard/admin-dashboard.html';
    } else if (userRole === 'student') {
        window.location.href = './dashboard/student-dashboard.html';
    } else if (userRole === 'volunteer') {
        window.location.href = './dashboard/volunteer-dashboard.html';
    }
}

// Check if user is already logged in
function checkUserSession() {
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    
    if (userRole && userEmail) {
        return {
            role: userRole,
            email: userEmail
        };
    }
    return null;
}

// Logout function
function logout() {
    localStorage.removeItem('userRole');
    localStorage.removeItem('userEmail');
    window.location.href = '../pages/student-login.html';
}

// Export functions for use in other files
window.AIpreneurs = {
    validateEmail: validateEmail,
    formatDate: formatDate,
    redirectByRole: redirectByRole,
    checkUserSession: checkUserSession,
    logout: logout,
    toggleMobileMenu: toggleMobileMenu
};

console.log('AIpreneurs Global Challenge 2025 - Main Script Loaded');
